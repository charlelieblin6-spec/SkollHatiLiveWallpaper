package fr.skollhati.wallpaper

import java.time.LocalDate
import kotlin.math.*

object SolarTimes {
    data class Day(val sunrise: Double, val sunset: Double) // local decimal hours
    fun forDate(date: LocalDate, latitude: Double, longitude: Double, utcOffsetHours: Double): Day? {
        val n = date.dayOfYear.toDouble()
        val lngHour = longitude / 15.0
        fun event(isSunrise: Boolean): Double? {
            val t = n + ((if (isSunrise) 6.0 else 18.0) - lngHour) / 24.0
            val m = 0.9856 * t - 3.289
            var l = m + 1.916 * sin(Math.toRadians(m)) + 0.020 * sin(2 * Math.toRadians(m)) + 282.634
            l = (l % 360 + 360) % 360
            var ra = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(l))))
            ra = (ra % 360 + 360) % 360
            val lq = floor(l / 90) * 90; val raq = floor(ra / 90) * 90
            ra = (ra + lq - raq) / 15.0
            val sinDec = 0.39782 * sin(Math.toRadians(l))
            val cosDec = cos(asin(sinDec))
            val cosH = (cos(Math.toRadians(90.833)) - sinDec * sin(Math.toRadians(latitude))) / (cosDec * cos(Math.toRadians(latitude)))
            if (cosH > 1 || cosH < -1) return null
            val h = (if (isSunrise) 360.0 - Math.toDegrees(acos(cosH)) else Math.toDegrees(acos(cosH))) / 15.0
            val utc = h + ra - 0.06571 * t - 6.622 - lngHour
            return ((utc + utcOffsetHours) % 24 + 24) % 24
        }
        val rise = event(true) ?: return null
        val set = event(false) ?: return null
        return Day(rise, set)
    }
    fun moonIllumination(date: LocalDate): Double {
        val knownNewMoon = LocalDate.of(2000, 1, 6)
        val age = ((date.toEpochDay() - knownNewMoon.toEpochDay()) % 29.530588853 + 29.530588853) % 29.530588853
        return (1.0 - cos(2 * Math.PI * age / 29.530588853)) / 2.0
    }
}
