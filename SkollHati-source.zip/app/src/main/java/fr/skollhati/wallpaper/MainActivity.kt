package fr.skollhati.wallpaper

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat

class MainActivity : Activity() {
    private val requestCode = 41
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 48, 36, 36) }
        layout.addView(TextView(this).apply {
            text = "SKÖLL & HATI\n\nUn fond nordique qui suit le cycle solaire de ta position.\n\nAutorise la localisation pour calculer le lever et le coucher du Soleil. Le fond utilise ensuite l'heure locale du téléphone (Europe/Paris en France).\n\nCette première version fait évoluer l'ambiance jour/nuit ; les loups et les astres de l'illustration restent intégrés à l'image."
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "Autoriser la localisation et choisir le fond"
            setOnClickListener {
                if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
                } else openWallpaperPicker()
            }
        })
        setContentView(layout)
        saveLastKnownLocation()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            saveLastKnownLocation(); openWallpaperPicker()
        }
    }
    private fun saveLastKnownLocation() {
        val fine = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc: Location? = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).firstNotNullOfOrNull { p ->
                try { if (lm.isProviderEnabled(p)) lm.getLastKnownLocation(p) else null } catch (_: SecurityException) { null }
            }
            if (loc != null) getSharedPreferences("solar", MODE_PRIVATE).edit().putFloat("lat", loc.latitude.toFloat()).putFloat("lon", loc.longitude.toFloat()).apply()
        } catch (_: Exception) { }
    }
    private fun openWallpaperPicker() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, NordicWallpaperService::class.java))
        startActivity(intent)
    }
}
