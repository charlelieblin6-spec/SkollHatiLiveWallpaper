package fr.skollhati.wallpaper

import android.graphics.*
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min

class NordicWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = NordicEngine()
    inner class NordicEngine : Engine() {
        private val image by lazy { BitmapFactory.decodeResource(resources, R.drawable.nordic_scene) }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var visible = false
        private val handler = android.os.Handler(mainLooper)
        private val tick = object : Runnable { override fun run() { drawFrame(); if (visible) handler.postDelayed(this, 60_000L) } }
        override fun onVisibilityChanged(visible: Boolean) { this.visible = visible; handler.removeCallbacks(tick); if (visible) tick.run() }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { super.onSurfaceChanged(holder, format, width, height); drawFrame() }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) { visible = false; handler.removeCallbacks(tick); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val w = canvas.width.toFloat(); val h = canvas.height.toFloat()
                val scale = max(w / image.width, h / image.height)
                val dw = image.width * scale; val dh = image.height * scale
                val left = (w - dw) / 2f; val top = (h - dh) / 2f
                canvas.drawBitmap(image, null, RectF(left, top, left + dw, top + dh), paint)
                val now = LocalDateTime.now()
                val zone = ZoneId.systemDefault()
                val offset = zone.rules.getOffset(now.atZone(zone).toInstant()).totalSeconds / 3600.0
                val prefs = getSharedPreferences("solar", MODE_PRIVATE)
                val lat = prefs.getFloat("lat", 46.6f).toDouble()
                val lon = prefs.getFloat("lon", 1.9f).toDouble()
                val times = SolarTimes.forDate(now.toLocalDate(), lat, lon, offset)
                val hour = now.hour + now.minute / 60.0
                val darkness = if (times == null) 0.45 else when {
                    hour in times.sunrise..times.sunset -> 0.08
                    else -> {
                        val mid = if (hour > times.sunset) (hour - times.sunset) / max(0.1, 24 - times.sunset + times.sunrise) else (24 - times.sunset + hour) / max(0.1, 24 - times.sunset + times.sunrise)
                        0.32 + 0.22 * (0.5 - 0.5 * kotlin.math.cos(2 * Math.PI * mid))
                    }
                }
                paint.color = Color.WHITE
                val overlay = Paint().apply { color = Color.argb((min(0.58, max(0.0, darkness)) * 255).toInt(), 5, 10, 32) }
                canvas.drawRect(0f, 0f, w, h, overlay)
                // Subtle atmospheric pulse; the art remains crisp and legible.
                val moon = SolarTimes.moonIllumination(now.toLocalDate())
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb((moon * 20).toInt(), 150, 190, 255); maskFilter = BlurMaskFilter(36f, BlurMaskFilter.Blur.NORMAL) }
                canvas.drawCircle(w * 0.82f, h * 0.38f, 24f, glow)
            } catch (_: Exception) { } finally { if (canvas != null) holder.unlockCanvasAndPost(canvas) }
        }
    }
}
