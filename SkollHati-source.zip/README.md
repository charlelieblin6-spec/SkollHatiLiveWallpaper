# Sköll & Hati — fond d'écran animé Android

Projet Android Studio en Kotlin. Il installe un service de fond d'écran animé utilisant l'illustration nordique incluse.

## Fonctionnalités de cette première version
- Demande l'autorisation de localisation et mémorise la dernière position connue.
- Calcule approximativement les heures locales de lever et coucher du Soleil à partir de la date, de la latitude/longitude et du fuseau horaire du téléphone.
- Adapte l'assombrissement de l'illustration à la période diurne/nocturne et calcule l'illumination lunaire.
- Rafraîchit l'affichage chaque minute.

## Limites à connaître
L'illustration intégrée contient déjà les deux loups, le Soleil et la Lune : ces éléments ne se déplacent donc pas indépendamment dans cette version. L'illumination lunaire est une estimation basée sur le cycle synodique moyen, pas une éphéméride astronomique de précision. La position est la dernière position connue disponible au moment de l'ouverture de l'application ; Android peut nécessiter une nouvelle ouverture pour actualiser la localisation.

## Compiler
Ouvrir le dossier dans Android Studio (JDK 17, Android Gradle Plugin 8.7.3), laisser Gradle synchroniser, puis construire l'APK via **Build > Build APK(s)**. Installer l'APK sur le téléphone, ouvrir « Sköll & Hati », autoriser la localisation, puis choisir le fond d'écran animé proposé.
