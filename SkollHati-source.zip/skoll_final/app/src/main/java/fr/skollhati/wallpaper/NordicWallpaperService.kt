package fr.skollhati.wallpaper

import android.graphics.*
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.os.Handler
import java.time.Instant
import kotlin.math.*

class NordicWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = NordicEngine()

    inner class NordicEngine : Engine() {
        private val scene by lazy { BitmapFactory.decodeResource(resources, R.drawable.nordic_scene) }
        private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val handler = Handler(mainLooper)
        private var visible = false
        private var frame = 0L
        private var lastAstronomy = 0L
        private var sun = SolarTimes.Horizontal(180.0, 30.0)
        private var moon = SolarTimes.Horizontal(220.0, 10.0)
        private var latitude = 46.6
        private var longitude = 1.9
        private val tick = object : Runnable {
            override fun run() {
                if (visible) {
                    drawFrame()
                    handler.postDelayed(this, 33L)
                }
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(tick)
            if (v) tick.run()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(tick)
            super.onDestroy()
        }

        private fun updateAstronomy(now: Instant) {
            val prefs = getSharedPreferences("solar", MODE_PRIVATE)
            latitude = prefs.getFloat("lat", 46.6f).toDouble().coerceIn(-89.9, 89.9)
            longitude = prefs.getFloat("lon", 1.9f).toDouble().coerceIn(-180.0, 180.0)
            sun = SolarTimes.sunPosition(now, latitude, longitude)
            moon = SolarTimes.moonPosition(now, latitude, longitude)
            lastAstronomy = now.epochSecond
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val w = canvas.width.toFloat(); val h = canvas.height.toFloat()
                val bg = scene
                val scale = max(w / bg.width, h / bg.height)
                val dw = bg.width * scale; val dh = bg.height * scale
                val left = (w - dw) / 2f; val top = (h - dh) / 2f
                canvas.drawBitmap(bg, null, RectF(left, top, left + dw, top + dh), bitmapPaint)

                val now = Instant.now()
                if (now.epochSecond - lastAstronomy >= 60L) updateAstronomy(now)
                val night = (1.0 - ((sun.altitude + 6.0) / 28.0)).coerceIn(0.0, 1.0)
                val tint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb((night * 48).toInt(), 4, 9, 32) }
                canvas.drawRect(0f, 0f, w, h, tint)

                // Project real azimuth/altitude to a broad sky dome, clamping below-horizon bodies to the skyline.
                val sunPoint = project(sun.azimuth, sun.altitude, w, h)
                val moonPoint = project(moon.azimuth, moon.altitude, w, h)
                drawOrb(canvas, sunPoint.first, sunPoint.second, max(16f, w * .022f), Color.rgb(255, 150, 42), true)
                drawMoon(canvas, moonPoint.first, moonPoint.second, max(13f, w * .018f), now)

                val t = frame / 5.2f
                drawOrbitTrail(canvas, sunPoint.first, sunPoint.second, w * .20f, Color.rgb(255, 135, 35))
                drawOrbitTrail(canvas, moonPoint.first, moonPoint.second, w * .20f, Color.rgb(75, 185, 255))
                // Larger independent vector wolves; the gait is animated continuously at display refresh cadence.
                val wolfSize = w * .205f
                drawWolf(canvas, (sunPoint.first - wolfSize * .86f).coerceIn(-wolfSize * .15f, w - wolfSize), sunPoint.second + h * .006f, wolfSize, t, true)
                drawWolf(canvas, (moonPoint.first - wolfSize * .86f).coerceIn(-wolfSize * .15f, w - wolfSize), moonPoint.second + h * .006f, wolfSize, t + 1.7f, false)
                drawParticles(canvas, w, h, frame)
                frame++
            } catch (_: Exception) {
                // A transient rendering issue must not kill the wallpaper engine.
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun project(azimuth: Double, altitude: Double, w: Float, h: Float): Pair<Float, Float> {
            val x = (w * (.5 + .43 * sin(Math.toRadians(azimuth)))).toFloat()
            val alt = altitude.coerceIn(-8.0, 85.0)
            val y = (h * (.36 - .30 * (alt / 90.0))).toFloat().coerceIn(h * .035f, h * .48f)
            return x to y
        }

        private fun drawOrb(c: Canvas, x: Float, y: Float, r: Float, color: Int, fire: Boolean) {
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; alpha = 135; maskFilter = BlurMaskFilter(r * 1.45f, BlurMaskFilter.Blur.NORMAL) }
            c.drawCircle(x, y, r * 1.55f, glow)
            c.drawCircle(x, y, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
            c.drawCircle(x - r * .22f, y - r * .22f, r * .45f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = if (fire) Color.rgb(255, 238, 190) else Color.rgb(230, 245, 255); alpha = 225 })
        }

        private fun drawMoon(c: Canvas, x: Float, y: Float, r: Float, now: Instant) {
            val p = SolarTimes.moonIllumination(now)
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(130, 195, 255); alpha = 110; maskFilter = BlurMaskFilter(r, BlurMaskFilter.Blur.NORMAL) }
            c.drawCircle(x, y, r * 1.4f, glow)
            val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(190, 218, 245) }
            c.drawCircle(x, y, r, base)
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(28, 43, 69); alpha = 235 }
            val offset = ((1.0 - 2.0 * p) * r).toFloat()
            c.drawOval(RectF(x - r + offset, y - r, x + r + offset, y + r), shadow)
        }

        private fun drawOrbitTrail(c: Canvas, x: Float, y: Float, length: Float, color: Int) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; alpha = 105; style = Paint.Style.STROKE; strokeWidth = 4.5f; strokeCap = Paint.Cap.ROUND; maskFilter = BlurMaskFilter(7f, BlurMaskFilter.Blur.NORMAL) }
            val path = Path().apply {
                moveTo(x - length, y + 16f)
                cubicTo(x - length * .72f, y - 30f, x - length * .34f, y + 36f, x - length * .12f, y + 4f)
            }
            c.drawPath(path, p)
        }

        private fun drawWolf(c: Canvas, x: Float, y: Float, size: Float, phase: Float, fire: Boolean) {
            val save = c.save(); c.translate(x, y); c.scale(size / 190f, size / 190f)
            val dark = if (fire) Color.rgb(34, 24, 25) else Color.rgb(16, 37, 59)
            val glowColor = if (fire) Color.rgb(255, 126, 35) else Color.rgb(75, 190, 255)
            val pulse = sin(phase)
            val bob = abs(cos(phase)) * 8f
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = glowColor; alpha = 170; style = Paint.Style.STROKE; strokeWidth = 12f; strokeCap = Paint.Cap.ROUND; maskFilter = BlurMaskFilter(6f, BlurMaskFilter.Blur.NORMAL) }
            val body = Path().apply { moveTo(18f, 70f + bob); cubicTo(34f, 37f + bob, 82f, 37f + bob, 112f, 55f + bob); lineTo(140f, 46f + bob); lineTo(158f, 28f + bob); lineTo(155f, 51f + bob); lineTo(181f, 58f + bob); lineTo(163f, 71f + bob); lineTo(178f, 83f + bob); lineTo(148f, 88f + bob); cubicTo(112f, 110f + bob, 61f, 105f + bob, 29f, 91f + bob); close() }
            c.drawPath(body, glow); c.drawPath(body, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = dark })
            val mane = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = glowColor; alpha = 235; style = Paint.Style.STROKE; strokeWidth = 3.8f; strokeCap = Paint.Cap.ROUND }
            val manePath = Path().apply { moveTo(38f, 57f+bob); lineTo(23f, 32f+bob); lineTo(55f, 49f+bob); lineTo(48f, 21f+bob); lineTo(77f, 44f+bob); lineTo(86f, 22f+bob); lineTo(103f, 47f+bob); lineTo(119f, 37f+bob) }
            c.drawPath(manePath, mane)
            val tail = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = glowColor; style = Paint.Style.STROKE; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND }
            c.drawPath(Path().apply { moveTo(28f, 78f+bob); cubicTo(5f, 72f+bob, 8f, 49f+bob, 1f, 37f+bob) }, tail)
            val legPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = dark; style = Paint.Style.STROKE; strokeWidth = 10f; strokeCap = Paint.Cap.ROUND }
            val legGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = glowColor; alpha = 205; style = Paint.Style.STROKE; strokeWidth = 3f; strokeCap = Paint.Cap.ROUND }
            val swing = pulse * 34f; val lift = abs(cos(phase)) * 17f
            val legs = listOf(
                Path().apply { moveTo(51f, 88f+bob); quadTo(40f+swing, 104f-lift+bob, 25f-swing, 122f+bob) },
                Path().apply { moveTo(77f, 93f+bob); quadTo(91f-swing, 105f+lift+bob, 106f+swing, 119f+bob) },
                Path().apply { moveTo(119f, 84f+bob); quadTo(132f+swing, 100f-lift+bob, 146f-swing, 116f+bob) },
                Path().apply { moveTo(139f, 81f+bob); quadTo(151f-swing, 99f+lift+bob, 164f+swing, 113f+bob) }
            )
            legs.forEach { c.drawPath(it, legPaint); c.drawPath(it, legGlow) }
            c.drawCircle(161f, 58f+bob, 3.2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            c.restoreToCount(save)
        }

        private fun drawParticles(c: Canvas, w: Float, h: Float, f: Long) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 190, 110); alpha = 135; maskFilter = BlurMaskFilter(3f, BlurMaskFilter.Blur.NORMAL) }
            repeat(18) { i ->
                val x = ((f * (1 + i % 3) + i * 83L) % w.toLong().coerceAtLeast(1)).toFloat()
                val y = h * (.10f + (i % 8) * .047f) + sin(f * .035 + i).toFloat() * 7f
                c.drawCircle(x, y, 1.2f + (i % 3), p)
            }
        }
    }
}
