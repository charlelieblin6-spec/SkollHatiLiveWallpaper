package fr.skollhati.wallpaper

import java.time.Instant
import java.time.ZoneOffset
import kotlin.math.*

/** On-device, network-free low-order ephemeris. Solar accuracy is typically within about 1 degree;
 * lunar position is a simplified orbital model and is intended for an animated wallpaper, not navigation. */
object SolarTimes {
    data class Horizontal(val azimuth: Double, val altitude: Double)

    fun sunPosition(instant: Instant, latitude: Double, longitude: Double): Horizontal {
        val jd = instant.epochSecond / 86400.0 + 2440587.5
        val t = (jd - 2451545.0) / 36525.0
        val l0 = norm(280.46646 + t * (36000.76983 + 0.0003032 * t))
        val m = 357.52911 + t * (35999.05029 - 0.0001537 * t)
        val e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
        val c = sin(rad(m)) * (1.914602 - t * (0.004817 + 0.000014 * t)) + sin(rad(2*m)) * (0.019993 - 0.000101*t) + sin(rad(3*m))*0.000289
        val omega = 125.04 - 1934.136*t
        val lambda = l0 + c - 0.00569 - 0.00478*sin(rad(omega))
        val eps0 = 23.0 + (26.0 + (21.448 - t*(46.815 + t*(0.00059 - t*0.001813)))/60.0)/60.0
        val eps = eps0 + 0.00256*cos(rad(omega))
        val decl = asin(sin(rad(eps))*sin(rad(lambda)))
        val y = tan(rad(eps)/2).pow(2)
        val eq = 4 * Math.toDegrees(y*sin(2*rad(l0)) - 2*e*sin(rad(m)) + 4*e*y*sin(rad(m))*cos(2*rad(l0)) - 0.5*y*y*sin(4*rad(l0)) - 1.25*e*e*sin(2*rad(m)))
        val utc = instant.atZone(ZoneOffset.UTC)
        val utcMinutes = utc.hour*60.0 + utc.minute + utc.second/60.0
        val trueSolar = ((utcMinutes + eq + 4*longitude) % 1440.0 + 1440.0) % 1440.0
        val hourAngle = rad(trueSolar / 4.0 - 180.0)
        return horizontal(latitude, decl, hourAngle)
    }

    /** Simplified lunar orbital elements (Meeus-style), adequate for approximate sky placement. */
    fun moonPosition(instant: Instant, latitude: Double, longitude: Double): Horizontal {
        val d = instant.epochSecond / 86400.0 + 2440587.5 - 2451543.5
        val n = rad(norm(125.1228 - 0.0529538083*d))
        val inc = rad(5.1454)
        val w = rad(norm(318.0634 + 0.1643573223*d))
        val a = 60.2666; val ecc = 0.0549
        val m = rad(norm(115.3654 + 13.0649929509*d))
        var eAnom = m + ecc*sin(m)*(1+ecc*cos(m))
        repeat(6) { eAnom -= (eAnom - ecc*sin(eAnom) - m)/(1-ecc*cos(eAnom)) }
        val xv = a*(cos(eAnom)-ecc); val yv = a*sqrt(1-ecc*ecc)*sin(eAnom)
        val v = atan2(yv,xv); val r = hypot(xv,yv)
        val xh = r*(cos(n)*cos(v+w)-sin(n)*sin(v+w)*cos(inc))
        val yh = r*(sin(n)*cos(v+w)+cos(n)*sin(v+w)*cos(inc))
        val zh = r*sin(v+w)*sin(inc)
        var lonEcl = atan2(yh,xh); var latEcl = atan2(zh,hypot(xh,yh))
        // Principal lunar perturbations improve the low-order orbital solution.
        val sunMean = rad(norm(356.0470 + 0.9856002585*d))
        val moonMean = m
        val elongation = rad(norm(297.8501921 + 12.19074912*d))
        lonEcl += rad(-1.274)*sin(moonMean-2*elongation) + rad(0.658)*sin(2*elongation) - rad(0.186)*sin(sunMean)
        latEcl += rad(-0.173)*sin(moonMean-2*elongation)
        val eps = rad(23.4393 - 3.563E-7*d)
        val xe = cos(lonEcl)*cos(latEcl)
        val ye = sin(lonEcl)*cos(latEcl)*cos(eps)-sin(latEcl)*sin(eps)
        val ze = sin(lonEcl)*cos(latEcl)*sin(eps)+sin(latEcl)*cos(eps)
        val ra = atan2(ye,xe); val dec = asin(ze)
        val jd = d + 2451543.5
        val gmst = rad(norm(280.46061837 + 360.98564736629*(jd-2451545.0)))
        val ha = normRad(gmst + rad(longitude) - ra)
        return horizontal(latitude, dec, ha)
    }

    /** Illuminated fraction of the Moon, 0=new and 1=full. */
    fun moonIllumination(instant: Instant): Double {
        val days = (instant.epochSecond / 86400.0 + 2440587.5) - 2451550.1
        val phase = ((days / 29.530588853) % 1.0 + 1.0) % 1.0
        return (1.0 - cos(2.0 * Math.PI * phase)) / 2.0
    }

    private fun horizontal(latDeg: Double, dec: Double, ha: Double): Horizontal {
        val lat = rad(latDeg)
        val alt = asin((sin(lat)*sin(dec)+cos(lat)*cos(dec)*cos(ha)).coerceIn(-1.0,1.0))
        val az = atan2(sin(ha), cos(ha)*sin(lat)-tan(dec)*cos(lat)) + Math.PI
        return Horizontal(norm(Math.toDegrees(az)), Math.toDegrees(alt))
    }
    private fun rad(v: Double)=Math.toRadians(v)
    private fun norm(v: Double)=((v%360)+360)%360
    private fun normRad(v: Double)=((v%(2*Math.PI))+2*Math.PI)%(2*Math.PI)
}
