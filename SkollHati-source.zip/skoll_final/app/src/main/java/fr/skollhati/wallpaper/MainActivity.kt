package fr.skollhati.wallpaper

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat

class MainActivity : Activity() {
    private val requestCode = 41
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(42, 52, 42, 42) }
        layout.addView(TextView(this).apply {
            text = "SKÖLL & HATI\n\nSköll poursuit le Soleil et Hati poursuit la Lune. Les deux chasseurs galopent en continu ; leurs positions célestes sont recalculées sur le téléphone, sans Internet.\n\nAutorise la localisation pour utiliser le ciel au-dessus de ta position. Si tu refuses ou si aucun relevé n'est disponible, une position de secours en France est utilisée."
            textSize = 18f
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, 28, 0, 24) }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Actualiser ma position"
            setOnClickListener {
                if (!hasLocationPermission()) ActivityCompat.requestPermissions(this@MainActivity,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
                else fetchLocation()
            }
        })
        layout.addView(Button(this).apply { text = "Choisir le fond d'écran"; setOnClickListener { openWallpaperPicker() } })
        setContentView(layout)
        status.text = "Position : " + getSharedPreferences("solar", MODE_PRIVATE).getString("label", "position de secours en France")
    }

    private fun hasLocationPermission(): Boolean =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) fetchLocation()
            else { status.text = "Localisation refusée : position de secours en France."; openWallpaperPicker() }
        }
    }

    @Suppress("MissingPermission")
    private fun fetchLocation() {
        if (!hasLocationPermission()) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val prefs = getSharedPreferences("solar", MODE_PRIVATE)
        var best: Location? = null
        try {
            for (provider in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
                try {
                    val loc = lm.getLastKnownLocation(provider)
                    if (loc != null && (best == null || loc.time > best!!.time)) best = loc
                } catch (_: Exception) { }
            }
            // Prefer a fresh one-shot fix. A cached fix is retained as a fallback if providers are unavailable.
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    lm.removeUpdates(this)
                    prefs.edit().putFloat("lat", location.latitude.toFloat()).putFloat("lon", location.longitude.toFloat())
                        .putString("label", "position du téléphone actualisée").apply()
                    status.text = "Position actualisée. Le ciel local sera suivi."
                    openWallpaperPicker()
                }
                @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider != null) {
                lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
                status.text = "Recherche de ta position…"
                if (best != null && System.currentTimeMillis() - best!!.time < 10 * 60 * 1000L) {
                    prefs.edit().putFloat("lat", best!!.latitude.toFloat()).putFloat("lon", best!!.longitude.toFloat())
                        .putString("label", "dernière position connue").apply()
                }
            } else {
                if (best != null) {
                    prefs.edit().putFloat("lat", best!!.latitude.toFloat()).putFloat("lon", best!!.longitude.toFloat())
                        .putString("label", "dernière position connue").apply()
                    status.text = "Dernière position connue enregistrée."
                } else status.text = "Position indisponible : position de secours en France."
                openWallpaperPicker()
            }
        } catch (_: Exception) {
            status.text = "Position indisponible : position de secours en France."
            openWallpaperPicker()
        }
    }

    private fun openWallpaperPicker() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, NordicWallpaperService::class.java)
        )
        startActivity(intent)
    }
}
