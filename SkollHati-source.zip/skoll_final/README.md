# Sköll & Hati – Live Wallpaper (source)

Android live wallpaper project for the Norse-inspired Sköll & Hati scene.

## Current changes
- Enlarged the two separately drawn vector wolves so their gallop is visible on a phone screen.
- Increased the stride and body bounce animation.
- Expanded the glowing pursuit trails behind each wolf.
- Softened the transition in the upper sky/background artwork to reduce the visible horizontal edge.
- Keeps local solar/lunar position calculations and the optional location permission flow from the previous source.

## Build
This project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, and Java 17.

Open the `skoll_final` directory as the Android project in Android Studio, or run `gradle assembleDebug` in an environment with Android SDK 35 installed. The GitHub Actions workflow in `.github/workflows/build-apk.yml` can also build the debug APK.

## Important validation note
The source archive and XML resources have been checked for archive integrity and XML well-formedness. An Android SDK/Gradle build and on-device visual test have not been run in this environment. Run the GitHub Actions build before installing the APK. The visual animation should be checked on the target Honor device; frame rate and OEM wallpaper behavior can vary.
