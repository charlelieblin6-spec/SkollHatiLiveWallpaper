# Sköll & Hati — fond d'écran animé Android

Projet Android Kotlin `WallpaperService` pour un fond d'écran animé sur téléphone.

## Fonctionnalités
- Dessin animé continu (cadence cible ~30 images/s lorsque le fond est visible).
- Sköll et Hati sont dessinés indépendamment du décor ; leurs foulées sont animées.
- Position apparente du Soleil calculée localement à partir de l'heure UTC et des coordonnées géographiques (algorithme solaire NOAA simplifié).
- Position apparente de la Lune calculée localement avec des éléments orbitaux bas ordre et quelques perturbations principales. Ce calcul est approximatif, adapté à un fond d'écran, pas à la navigation ou à l'astronomie de précision.
- Fraction éclairée de la Lune approximative et assombrissement du décor selon la hauteur du Soleil.
- Localisation demandée au lancement ; dernière position connue utilisée si disponible, sinon coordonnées de secours en France (46.6 N, 1.9 E).
- Aucun accès Internet requis.

## Compilation
Le projet cible Android SDK 35, AGP 8.7.3, Kotlin 2.0.21 et JDK 17. Le workflow GitHub Actions fourni exécute `gradle assembleDebug` et publie `app-debug.apk` comme artefact `SkollHati-debug-apk`.

1. Décompresser le ZIP et pousser le contenu du dossier `skoll_final` à la racine du dépôt GitHub.
2. Dans GitHub, ouvrir **Actions** puis lancer **Build Skoll Hati APK** (workflow_dispatch).
3. Télécharger l'artefact `SkollHati-debug-apk`, extraire l'APK et l'installer sur Android.
4. Ouvrir l'application, autoriser la localisation, puis choisir le fond d'écran.

## Limites connues
- Le moteur de rendu et les calculs astronomiques sont intégrés au code, mais cette archive n'a pas été compilée dans un environnement Android SDK dans cet espace. Le succès de la compilation doit donc être confirmé par GitHub Actions.
- Le décor est une illustration fixe ; les loups animés sont des personnages vectoriels dessinés par le moteur, pas des sprites anatomiques photoréalistes. La composition de fond comporte encore quelques détails graphiques imparfaits issus de la retouche de l'illustration.
- Android peut réduire la fréquence de rendu ou suspendre l'animation lorsque l'écran est éteint, en économie d'énergie ou lorsque le fond n'est pas visible.
