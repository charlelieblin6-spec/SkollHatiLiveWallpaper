# Sköll & Hati Live Wallpaper — source v1.2

Android live wallpaper project for the Norse wolf chase.

## Changes in v1.2
- Replaced the primitive geometric wolf drawings with two separate, detailed transparent PNG character sprites.
- Sköll uses a dark, fire-lit wolf illustration; Hati uses a silver/blue frost-lit wolf illustration.
- Both sprites are rendered independently and receive continuous bob/pitch animation while following the computed Sun/Moon positions.
- Kept the existing local Sun/Moon position calculations, day/night tint and particle effects.

## Build
The GitHub Actions workflow builds `app/build/outputs/apk/debug/app-debug.apk` with JDK 17 and Gradle 8.9.

## Important limitations
- The wolf illustrations are full-body running poses. This version animates each complete sprite (position, bob and pitch); it does not yet articulate individual legs or generate a multi-frame gait.
- Sun/Moon positions use the project's existing astronomy implementation and saved coordinates. GPS permission/location acquisition is not automatically guaranteed by this wallpaper service; use the app's location settings or fallback coordinates as configured in the app.
- The archive is source code only. Run GitHub Actions to confirm the Android build and produce the APK.
